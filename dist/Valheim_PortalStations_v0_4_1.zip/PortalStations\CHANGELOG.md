# 0.4.1
    fix: sync station renames in destination list
    fix: fix station renaming not possible
    feat: improved publish scripts

# 0.3.0
    fix: sync list of destinations from server to clients
# 0.2.0
    feat: fixed resource usage to 25 stone, 20 greydwarf eyes and 4 surtling cores
# 0.1.0
    feat: improved GUI logic
    fix: GUI not intuitive enough
    fix: distant portal stations not listed in teleport destinations
    fix: station not dropping resources when destroyed
    fix: fixed resource usage to 25 stone, 20 greydwarf eyes and 3 surtling cores

# 0.0.1

 - Initial version